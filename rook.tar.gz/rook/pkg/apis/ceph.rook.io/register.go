package cephrookio

const (
	GroupName = "ceph.rook.io"
)
