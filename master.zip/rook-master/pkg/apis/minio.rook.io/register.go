package miniorookio

const (
	GroupName = "minio.rook.io"
)
