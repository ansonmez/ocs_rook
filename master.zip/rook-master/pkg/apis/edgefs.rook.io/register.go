package edgefsrookio

const (
	GroupName = "edgefs.rook.io"
)
