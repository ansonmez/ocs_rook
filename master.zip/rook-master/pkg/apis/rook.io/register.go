package rookio

const (
	GroupName = "rook.io"
)
